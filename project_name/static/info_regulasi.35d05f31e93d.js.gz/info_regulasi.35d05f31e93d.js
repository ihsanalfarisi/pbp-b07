$(document).ready(function () {
  $("#Malaysia").load("malaysia.html/");
  $("#Singapore").load("singapore.html/");
  $("#Thailand").load("thailand.html/");
});
